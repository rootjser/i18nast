/**
 * 替换代码覆盖文件，生成语言文件
 */
const {getSrc, AST, addImport, mapToJson} = require('./utils');
const fs = require('fs');

function step3(type) {
  const translate = JSON.parse(
    fs.readFileSync(`./${type}-zh-en.json`, {encoding: 'utf-8'}),
  );
  const zhWords = JSON.parse(
    fs.readFileSync(`./${type}-all.json`, {encoding: 'utf-8'}),
  );
  const ast = new AST(type, translate, zhWords);
  getSrc(type).forEach((filepath) => {
    try {
      ast.transform(filepath);
    } catch (e) {
      console.error(`文件存在语法错误，请检查: ${filepath}`);
      throw e;
    }
  });

  if (ast.result.size === 0) {
    console.log('没有新中文要替换');
    return;
  }
  console.log(ast.result.size, Object.keys(translate).length);
  if (ast.result.size !== Object.keys(translate).length) {

  }

  // 补上 import
  ast.changedFiles.forEach((filepath) => {
    try {
      addImport(filepath, type);
    } catch (e) {
      console.error(filepath, e);
      throw e;
    }
  });

  function writeJSON() {
    const all = new Map();
    ['zh-CN', 'en'].forEach(lang => {
      ast.result.forEach((value, key) => {
        const arr = key.split('.');
        let file;
        switch (arr[0]) {
          case 'themes':
          case 'routes':
          case 'components':
            file = `../src/locales/${lang}/${arr[0]}/${arr[1]}.json`;
            break;
          case 'sponsor':
            file = `../src/sponsor/locales/${lang}/${arr[1]}.json`;
            break;
          default:
            file = `../src/locales/${lang}/${arr[0]}.json`;
        }
        if (!all.has(file)) {
          all.set(file, new Map());
        }
        switch (lang) {
          case 'zh-CN':
            all.get(file).set(arr[arr.length - 1], value.zh);
            break;
          case 'en':
            all.get(file).set(arr[arr.length - 1], value.en);
            break;
        }
      });
    });
    all.forEach((value, key) => {
      if (value.size === 0) {
        return;
      }
      let json = mapToJson(value);
      // if (fs.existsSync(key)) {
      //   const previous = fs.readFileSync(key, {encoding: 'utf-8'});
      //   if (previous.length > 0) {
      //     json = Object.assign(JSON.parse(previous), json);
      //   }
      // }
      fs.writeFileSync(key, JSON.stringify(json, null, 2));
    });
  }

  writeJSON();
  fs.writeFileSync('result.json', JSON.stringify(mapToJson(ast.result), null, 2));
}

// step3('themes');
step3('app');
