/**
 * 提取中文
 */
const { getSrc, AST, mapToJson } = require("./utils");
const fs = require("fs");
const path = require("path");

function step1(type) {
  const ast = new AST(type);
  getSrc(type).forEach((filepath) => {
    try {
      ast.transform(filepath);
    } catch (e) {
      console.error(`文件存在语法错误，请检查: ${filepath}`);
      throw e;
    }
  });

  let json = {};
  ast.map.forEach((value, key) => {
    json[key] = value;
  });
  // 删掉同一文件下的同样的中文
  if (type === "app") {
    Object.keys(json).forEach((item) => {
      const chinese = json[item];
      const file = item.split("#")[0];
      Object.keys(json)
        .filter((it) => it.startsWith(file) && it !== item)
        .forEach((it) => {
          if (json[it] === chinese) {
            delete json[it];
          }
        });
    });
  }
  fs.writeFileSync(
    path.join(__dirname, `./${type}-all.json`),
    JSON.stringify(Object.values(json), null, 2)
  );
  const map = new Map();
  ast.map.forEach((value, key) => {
    map.set(value, key);
  });
  const set = {};
  map.forEach((value, key) => {
    set[value] = key;
  });
  fs.writeFileSync(
    path.join(__dirname, `./${type}-zh.json`),
    JSON.stringify(set, null, 2)
  );
  fs.writeFileSync(path.join(__dirname, `./${type}-en.json`), "{}");
}

step1("app");
step1("themes");
