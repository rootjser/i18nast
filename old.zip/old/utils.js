const fs = require('fs');
const path = require('path');
const recast = require('recast');
const builders = recast.types.builders;
const namedTypes = recast.types.namedTypes;
const OVERWRITE = true;

// 读取src目录
function getSrc(type) {
  const Regx = /\.(ts$|js$|tsx$|jsx$)/;
  // 过滤掉一些不想处理的文件
  const excludes = [
    '\\rsa-controller.ts',
    'src\\utils\\data.js',
    '\\imgColorSysTem',
    '\\imgTemGlobal',
    '\\routes.config.js',
    '\\tyscm.3.3.0.js',
    '\\utils\\local',
    'gt.js',
    'gt4.js',
    'src\\Empty.tsx',
    'languageSel\\index.tsx',
    'src\\pages\\home\\glassBlue\\components\\header\\index.tsx',
    'src\\index.tsx',
    'mqtt-chatroom',
  ];
  const sources = [];
  const scan = (param) => {
    const files = fs.readdirSync(param);
    files.forEach((file) => {
      const filepath = path.join(param, file);
      const stat = fs.statSync(filepath);
      if (stat.isDirectory()) {
        scan(filepath);
      } else if (Regx.test(path.extname(filepath))) {
        if (
          !excludes.some(
            (value) => filepath.endsWith(value) || filepath.includes(value),
          )
        ) {
          sources.push(filepath);
        }
      }
    });
  };
  scan(path.join(__dirname, `../src`));
  return sources.filter((item) => {
    if (!type) return true;
    if (type === 'themes') {
      return item.includes('src\\themes');
    } else {
      return !item.includes('src\\themes');
    }
  });
}

// 读取已经存在的国际化json
function getLocales(lang) {
  const sources = [];
  const scan = (param) => {
    const files = fs.readdirSync(param);
    files.forEach((file) => {
      const filepath = path.join(param, file);
      const stat = fs.statSync(filepath);
      if (stat.isDirectory()) {
        scan(filepath);
      } else if (path.extname(filepath) === '.json') {
        sources.push(filepath);
      }
    });
  };
  scan(path.join(__dirname, `../src/locales/${lang}`));
  return sources;
}

// 忽略图片文件名带中文的情况
function isImgPath(text) {
  return ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg'].some((item) =>
    text.includes(item),
  );
}

function isChinese(text) {
  return new RegExp('[\\u4E00-\\u9FFF]+', 'g').test(text);
}

function formatChinese(text) {
  // // 某些特殊写法的注释手动处理
  // if (text.startsWith('//')) {
  //   text = text.split('\r\n').pop();
  // }
  // 去掉首尾引号
  if (
    (text.startsWith("'") || text.startsWith('"')) &&
    (text.endsWith("'") || text.endsWith('"'))
  ) {
    text = text.substring(1);
    text = text.substring(0, text.length - 1);
  }
  // 去掉首尾换行空格
  text = text.trim();
  text = text.replaceAll('\\n', '');
  text = text.replaceAll(/\s+/g, ' ');
  return text;
}

function isIgnore(path) {
  let text = recast.print(path.node).code;
  text = formatChinese(text);
  if (text.startsWith('//')) {
    return true;
  }
  // 非中文不处理
  if (!isChinese(text) || isImgPath(text)) {
    return true;
  }
  // 忽略简单的判断
  return path?.name === 'test';
}

// 生成intl.get()表达式
function expressionGen(key) {
  return builders.callExpression.from({
    callee: builders.memberExpression.from({
      object: builders.identifier.from({
        name: 'intl',
      }),
      property: builders.identifier.from({
        name: 'get',
      }),
    }),
    arguments: [builders.stringLiteral(key)],
  });
}

// 生成id
function id(filepath, loc) {
  const arr = filepath.split('src')[1].split('\\').join('.').split('.');
  arr.pop();
  arr.shift();
  return `${arr.join('.')}.#${loc.start.line + 1}#${loc.end.column}`;
}

// 手动处理这些中文
const manualRegx = [
  /^(\d+)(分钟)$/,
  /^(\d+.?\d+)(元)$/,
  /^(≥?)(\d+)(条)$/,
  /^(\d+)(倍)$/,
  /^(步骤)(\d+\/\d+)$/,
  /^(有效投注额)(≥)(\d+)$/,
  /^(元)(~)$/,
  // 锁定中 （锁定中）
  /^(（)(.+)(）)$/,
  /^(\()(.+)(\))$/,
  /^(【)(.+)(】)$/,
  /\.{2,}$/,
  /^(≥)(\d+)(元)/,
  // 以标点符号开头或结尾的  比如 元 和 元：
  /^[:：？?！!，,。.](.+)$/,
  /^(.+)[:：？?！!，,。.]$/,
];

class AST {
  map = new Map();
  // 中英对照翻译文件
  translate = null;
  // 修改过的文件
  changedFiles = new Set();
  zhWords = [];
  // 最终结果
  result = new Map();
  sameKeys = new Map();
  // 已经存在的翻译
  locales = new Map();

  constructor(translate, zhWords) {
    if (translate && zhWords) {
      this.translate = translate;
      this.zhWords = zhWords;
      // try {
      //   ['zh-CN', 'en'].forEach((lang) => {
      //     getLocales(lang).forEach((item) => {
      //       const value = JSON.parse(
      //         fs.readFileSync(item, { encoding: 'utf8' }),
      //       );
      //       const arr = item.split('\\');
      //       let prefix;
      //       if (arr[arr.length - 2] === 'pages') {
      //         prefix = `pages.${arr[arr.length - 1]}`;
      //       } else {
      //         prefix = arr[arr.length - 1];
      //       }
      //       prefix = prefix.replaceAll('.json', '');
      //       if (lang === 'zh-CN') {
      //         this.locales.set(prefix, { zh: value });
      //       } else {
      //         this.locales.get(prefix).en = value;
      //       }
      //     });
      //   });
      // } catch (e) {
      //   console.log('现有翻译不存在');
      // }
    }
  }

  enKeyGen(zh, en, id, duplicate) {
    // 已经有了
    let exitsKey = '';
    this.result.forEach((value, key) => {
      if (value.zh === zh) {
        exitsKey = key;
      }
    });
    if (exitsKey) {
      return exitsKey;
    }
    // “吗” 被翻译成了? 手动处理下
    if (en === '?') {
      en = 'QuestionMark';
    }
    let enKey = en
      .replace(/[^a-zA-Z0-9\x20]/g, '')
      .replace(/^(\d+)/g, '')
      .trim()
      .split(' ')
      .map((item) => {
        return item
          .split('')
          .map((char, index) => {
            return index === 0 ? char.toUpperCase() : char;
          })
          .join('');
      })
      .slice(0, 5)
      .join('');
    const prefix = this.pathKeyGen(id, duplicate);
    const fullKey = prefix + '.' + enKey;
    // key重复了
    if (this.result.has(fullKey)) {
      // 不一样的中文，但是翻译成了一样的英文
      this.sameKeys.set(fullKey, this.sameKeys.get(fullKey) || 0);
    }
    // 和现有的key冲突了
    if (this.locales.has(prefix)) {
      const arr = Object.keys(this.locales.get(prefix).zh).filter((item) =>
        item.startsWith(enKey),
      );
      if (arr.length > 0) {
        const maxIndex = arr
          .map((item) => Number(item.split('_alias')[1] || 0))
          .sort()
          .reverse()[0];
        this.sameKeys.set(fullKey, this.sameKeys.get(fullKey) || maxIndex);
      }
    }
    if (this.sameKeys.has(fullKey)) {
      const index = this.sameKeys.get(fullKey) + 1;
      enKey += '_alias' + index;
      this.sameKeys.set(fullKey, index);
    }
    return prefix + '.' + enKey;
  }

  pathKeyGen(id, duplicate) {
    const paths = id.split('.');
    switch (paths[0]) {
      case 'components':
      case 'dto':
      case 'epics':
      case 'reducers':
      case 'static_data':
      case 'utils':
        if (duplicate) {
          return 'common.';
        } else {
          return `${paths[0]}.`;
        }
      // return `${paths[0]}.`;
      case 'themes':
        return 'themes.';
      case 'pages':
        return `${paths[0]}.${paths[1]}.`;
      default:
        // console.log(item);
        // return 'others.';
        throw new Error('请检查i18n脚本是否有缺失的case:' + paths[0]);
    }
  }

  // 已经翻译过的key
  getTranslatedKey(prefix, chinese) {
    if (!this.locales.has(prefix)) return;
    const json = this.locales.get(prefix).zh;
    for (let key in json) {
      if (json[key] === chinese) {
        return key;
      }
    }
  }

  setResult(chinese) {
    const translate = this.translate;
    if (!translate) {
      return;
    }
    let id = '';
    let key = '';
    // 公共json已经翻译
    if (this.getTranslatedKey('common', chinese)) {
      return this.getTranslatedKey('common', chinese);
    } else {
      // 中文有重复
      let duplicate =
        this.zhWords.filter((value) => {
          return value === chinese;
        }).length > 1;
      for (const item in translate) {
        if (translate[item].zh === chinese) {
          id = item;
          key = this.enKeyGen(
            translate[item].zh,
            translate[item].en,
            id,
            duplicate,
          );
          break;
        }
      }
      if (id === '') {
        throw new Error(
          '中文未翻译，需先执行step1和step2，未翻译的中文: ' + chinese,
        );
      }
      // 对应的目录json已经翻译
      if (this.getTranslatedKey(this.pathKeyGen(id, duplicate), chinese)) {
        return this.getTranslatedKey(this.pathKeyGen(id, duplicate), chinese);
      }
      this.result.set(key, {
        id,
        zh: this.translate[id].zh,
        en: this.translate[id].en,
      });
    }
    return key;
  }

  i18nGen({ jsx = false, template = false, filepath, chinese, loc }) {
    this.changedFiles.add(filepath);
    chinese = formatChinese(chinese);
    // 富文本特殊处理
    if (chinese.match(/(?<=>)[^<>]+(?=<)/g) || chinese.match(/<[^<>]+>/g)) {
      return this.richText({ jsx, filepath, chinese, loc, template });
    }
    // 手动处理一些特别的文本
    if (manualRegx.some((regx) => regx.test(chinese))) {
      return this.manualOptimizeText({ jsx, filepath, chinese, loc, template });
    }
    let key;
    if (this.translate) {
      key = this.setResult(chinese);
    } else {
      key = id(filepath, loc);
      if (this.map.has(key)) {
        key += '##';
      }
      this.map.set(key, chinese);
      this.zhWords.push(chinese);
    }
    const i18n = expressionGen(key);
    if (jsx) {
      return builders.jsxExpressionContainer.from({
        expression: i18n,
      });
    }
    if (template) {
      return `\$\{${recast.print(i18n).code}\}`;
    }
    return i18n;
  }

  // 手动优化一些文本，比如步骤1/9，步骤2/9这样的，只提取步骤
  manualOptimizeText({ jsx, filepath, chinese, loc, template }) {
    const regx = manualRegx.find((regx) => regx.test(chinese));
    const words = chinese.split(regx).filter((item) => isChinese(item));
    return this.complexText(words, { jsx, filepath, chinese, loc, template });
  }

  richText({ jsx, filepath, chinese, loc, template }) {
    const words = chinese
      .split(/<[^\u4e00-\u9fa5]+>/g)
      .filter((item) => isChinese(item));
    return this.complexText(words, { jsx, filepath, chinese, loc, template });
  }

  complexText(words, { jsx, filepath, chinese, loc, template }) {
    words.forEach((word, index) => {
      word = formatChinese(word);
      if (word.startsWith('<!--')) {
        return;
      }
      let key;
      if (this.translate) {
        key = this.setResult(word);
      } else {
        key = id(filepath, loc) + '#' + index;
        this.map.set(key, word);
        this.zhWords.push(word);
      }
      chinese = chinese.replace(
        word,
        '${' + recast.print(expressionGen(key)).code + '}',
      );
    });
    if (jsx) {
      return builders.jsxExpressionContainer.from({
        expression: recast.parse('`' + chinese + '`').program.body[0]
          .expression,
      });
    }
    const prefix = template ? '' : '`';
    return prefix + chinese + prefix;
  }

  transform(filepath) {
    const code = fs.readFileSync(filepath, { encoding: 'utf-8' });
    const ast = recast.parse(code, {
      parser: require('recast/parsers/typescript'),
    });
    // 字符串
    const visitStringLiteral = (path) => {
      if (isIgnore(path)) {
        return false;
      }
      const text = recast.print(path.node).code;
      let jsx = false;
      if (namedTypes.JSXAttribute.check(path.parentPath?.value)) {
        jsx = true;
      }
      path.replace(
        this.i18nGen({ filepath, chinese: text, loc: path.node.loc, jsx }),
      );
      return false;
    };
    // 模板字符串中的字符串
    const visitTemplateElement = (path) => {
      if (isIgnore(path)) {
        return false;
      }
      const text = recast.print(path.node).code;
      path.replace(
        this.i18nGen({
          filepath,
          loc: path.node.loc,
          chinese: text,
          template: true,
        }),
      );
      return false;
    };
    // JSX文本  <h1>你好</h1>
    const visitJSXText = (path) => {
      if (isIgnore(path)) {
        return false;
      }
      path.replace(
        this.i18nGen({
          filepath,
          jsx: true,
          chinese: path.value.value,
          loc: path.value.loc,
        }),
      );
      return false;
    };
    const _this = this;
    recast.visit(ast, {
      visitStringLiteral,
      visitTemplateElement,
      visitJSXText, // 对象定义 const obj = {'中文key不替换': 'value替换'}
      visitObjectProperty(path) {
        const value = path.value.value;
        if (namedTypes.StringLiteral.check(value)) {
          if (!isChinese(value.value) || isImgPath(value.value)) {
            return false;
          }
          path.value.value = _this.i18nGen({
            filepath,
            loc: value.loc,
            chinese: value.value,
          });
          return false;
        }
        this.traverse(path);
      },
      // 忽略 if(obj.func('中文'))....
      visitCallExpression(path) {
        if (path.name === 'test') {
          return false;
        }
        // 忽略console输出
        if (path.value?.callee?.object?.name === 'console') {
          return false;
        }
        // 忽略includes判断
        if (path.value?.callee?.property?.name === 'includes') {
          return false;
        }
        this.traverse(path);
      },
      // 处理复杂逻辑表达式
      visitLogicalExpression(path) {
        // 父级是if判断的不处理
        if (namedTypes.IfStatement.check(path?.parentPath?.node)) {
          return false;
        }
        this.traverse(path);
      },
      // 处理运算符 三元条件判断 a === '这里不会被替换' ? '这里的会被替换' : '这里的会被替换'
      visitBinaryExpression(path) {
        switch (path.value.operator) {
          case '===':
          case '!==':
          case '==':
          case '!=':
            return false;
        }
        if (path.name === 'test') return false;
        this.traverse(path);
      },
      // 忽略 enum {success = '成功'}
      visitTSEnumMember() {
        return false;
      },
      // 忽略 throw new Error('错误')
      visitThrowStatement() {
        return false;
      },
      visitTSTypeAnnotation() {
        return false;
      },
    });
    // console.log('处理文件', filepath);
    if (this.translate && OVERWRITE) {
      fs.writeFileSync(filepath, recast.print(ast).code);
    }
  }
}

// 头部插入import
function addImport(filepath) {
  const code = fs.readFileSync(filepath, { encoding: 'utf-8' });
  const ast = recast.parse(code, {
    parser: require('recast/parsers/typescript'),
  });
  let alreadyImported;
  recast.visit(ast, {
    visitImportDeclaration(path) {
      if (path.node.source.value === 'react-intl-universal') {
        alreadyImported = true;
      }
      return false;
    },
  });
  if (alreadyImported) {
    return;
  }
  ast.program.body.unshift("import intl from 'react-intl-universal';");
  if (OVERWRITE) {
    fs.writeFileSync(filepath, recast.print(ast).code);
  }
}

module.exports = {
  getSrc,
  addImport,
  AST,
  mapToJson: function (map) {
    let json = {};
    map.forEach((value, key) => {
      json[key] = value;
    });
    return json;
  },
  getLocales,
};
