const fs = require('fs');
const readline = require('readline');
const {getLocales} = require("./utils");

// 修复不正确格式的json
function format(file) {
  try {
    JSON.parse(fs.readFileSync(file, {encoding: 'utf8'}));
  } catch (e) {
    const obj = {};
    const fileStream = fs.createReadStream(file);
    readline
      .createInterface({
        input: fileStream,
        crlfDelay: Infinity,
      })
      .on('line', (line) => {
        const [first, ...rest] = line.split(':');
        if (line.split(':').length > 1) {
          const key = first.trim().replaceAll('"', '');
          let value = rest.join(':').trim();
          if (value.endsWith(',')) {
            value = value.slice(0, -1);
          }
          if (value.endsWith('"')) {
            value = value.slice(0, -1);
          }
          if (value.startsWith('"')) {
            value = value.slice(1);
          }
          obj[key] = value.replaceAll('\\"', '"').replaceAll('\\n', '\n');
        }
      })
      .on('close', () => {
        fs.writeFileSync(file, JSON.stringify(obj, null, 2));
      });
  }
}

// 创建国际化index.js文件
function createIndexFile(lang, folder) {
  const recast = require('recast');
  const builders = recast.types.builders;
  const names = fs
    .readdirSync(`../src/locales/${lang}${folder ? '/' + folder : ''}`)
    .filter((item) => !item.endsWith('.js'))
    .map((item) => item.replaceAll('.json', ''));
  const program = builders.program.from({
    body: [
      ...Array.from(names).map((name) => {
        return builders.importDeclaration.from({
          source: builders.stringLiteral(`./${name}`),
          specifiers: [
            builders.importDefaultSpecifier.from({
              local: builders.identifier.from({
                name: name.replaceAll('-', '_'),
              }),
            }),
          ],
        });
      }),
      builders.exportDefaultDeclaration.from({
        declaration: builders.objectExpression.from({
          properties: [
            ...Array.from(names).map((name) => {
              const flag = folder && !fs.existsSync(`../src/${folder}/${name}`);
              return builders.objectProperty.from({
                key: builders.stringLiteral(`${flag ? name.replaceAll('_', '-') : name}`),
                value: builders.identifier(`${name.replaceAll('-','_')}`),
              });
            }),
          ],
        }),
      }),
    ],
  });
  fs.writeFileSync(
    `../src/locales/${lang}${folder ? '/' + folder : ''}/index.js`,
    recast.print(program).code,
  );
}

// format('./app-en.json');
// format('./sponsor-en.json');
// createIndexFile('en','');
// createIndexFile('en', 'routes');
// createIndexFile('en', 'components');
// createIndexFile('zh-CN','');
// createIndexFile('zh-CN', 'routes');
// createIndexFile('zh-CN', 'components');

// 校准翻译
function translate() {
  const correct = JSON.parse(fs.readFileSync('./translate.json', {encoding: 'utf8'}));
  getLocales('zh-CN').forEach(file => {
    const zh = JSON.parse(fs.readFileSync(file, {encoding: 'utf8'}));
    const enFile = file.replaceAll('zh-CN', 'en');
    const en = JSON.parse(fs.readFileSync(enFile, {encoding: 'utf8'}));
    let modified = false;
    Object.keys(zh).forEach(key => {
      const find = Object.keys(correct).find(it => it === zh[key]);
      if (find) {
        en[key] = correct[find];
        modified = true;
      }
    });
    if (modified) {
      fs.writeFileSync(enFile, JSON.stringify(en, null, 2));
    }
  });
}

translate();
