/**
 * 将提取的中文翻译成英文后执行该任务，生成中英对照文件
 */
const fs = require('fs');
const path = require('path');

function combine(type) {
  const obj = {};
  const zh = JSON.parse(fs.readFileSync(`./${type}-zh.json`, {encoding: 'utf-8'}));
  const en = JSON.parse(fs.readFileSync(`./${type}-en.json`, {encoding: 'utf-8'}));

  if (Object.keys(zh).length > Object.keys(en).length) {
    Object.keys(zh).forEach((item) => {
      if (!en[item]) console.log(item);
    });
    Object.keys(en).forEach((item) => {
      if (!zh[item]) console.log(item);
    });
    throw new Error('缺少翻译');
  }

  for (const key in zh) {
    if (!zh[key] || !en[key]) {
      throw new Error('缺少翻译:' + key);
    }
    obj[key] = {
      zh: zh[key],
      en: en[key],
    };
  }

  fs.writeFileSync(
    path.join(__dirname, `./${type}-zh-en.json`),
    JSON.stringify(obj, null, 2),
  );
}

combine('app');
combine('themes');