// #!/usr/bin/env node
const lodash = require("loadsh");
const commander = require("commander");
const path = require("path");
const fs = require("fs");
const recast = require("recast");
const jscodeshift = require("jscodeshift");
// 工具
const Utils = {
  // 为真
  ifTrue(bl) {
    return (o) => (bl ? o : null);
  },
  // 文件类
  async createFileObjectSync(fullpath, options) {
    // 配置项
    const optionsSync = lodash.merge(
      {
        files: false,
      },
      options
    );
    // 判断是文件还是文件夹
    const stat = await new Promise((resolve, reject) => {
      fs.stat(fullpath, (error, stat) => {
        if (error) {
          reject();
          throw error;
        }
        resolve(stat);
      });
    });
    // 获得文件或者文件夹下所有文件
    const allFiles = Utils.ifTrue(optionsSync.files)(
      await new Promise((resolve, reject) => {
        if (stat.isFile()) {
          resolve([
            {
              fullpath: fullpath,
              isFile: stat.isFile(),
              readFileSync: () =>
                fs.readFileSync(fullpath, { encoding: "utf-8" }),
            },
          ]);
        } else {
          const allFilesTemp = [];
          fs.readdir(fullpath, async (error, files) => {
            if (error) {
              reject();
              throw error;
            }
            for (child of files) {
              const childFullPath = path.join(fullpath, child);
              const fileObject = await Utils.createFileObjectSync(
                childFullPath,
                optionsSync
              );
              allFilesTemp.push(...fileObject.allFiles);
            }
            resolve(allFilesTemp);
          });
        }
      })
    );

    return {
      fullpath: fullpath,
      isFile: stat.isFile(),
      allFiles: allFiles,
    };
  },
  // ast
  transform() {},
};
// 定义命令 i18nast transform projectdemo
commander.command("transform <fileOrfolder>").action(async (fileOrfolder) => {
  const fullPath = path.join(__dirname, fileOrfolder);
  const fileObject = await Utils.createFileObjectSync(fullPath, {
    files: true,
  });
  // console.log(fileObject);
  /**
   * D:\k8s\src>i18nast transform projectdemo\pages\activity\drawGift\drawGift.tsx
   * {
   *    fullpath: 'D:\\k8s\\src\\projectdemo\\pages\\activity\\drawGift\\drawGift.tsx',
   *    isFile: true,
   *    allFiles: [
   *        {
   *            fullpath: 'D:\\k8s\\src\\projectdemo\\pages\\activity\\drawGift\\drawGift.tsx',
   *            isFile: true,
   *            readFileSync: [Function: readFileSync]
   *        }
   *    ]
   * }
   */
  // fileObject.files 目录下所有文件
  // ast -> 提取中文信息
  fileObject.allFiles.forEach((item) => {
    const ast = recast.parse(item.readFileSync(), {
      parser: require("recast/parsers/typescript"),
    });
    console.log(ast);
  });
});
// 绑定解析
commander.parse(process.argv);
